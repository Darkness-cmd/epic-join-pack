scoreboard players set @s dd_wait -1
scoreboard players set @s dd_t 0
title @s times 0 2 0
stopsound @s master darkness_death:death_animation
playsound darkness_death:death_animation master @s ~ ~ ~ 1 1 1
