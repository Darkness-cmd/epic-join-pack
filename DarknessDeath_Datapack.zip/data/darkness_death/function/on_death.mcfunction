# Se ejecuta como el jugador que acaba de morir.
scoreboard players set @s dd_deaths 0
scoreboard players set @s dd_t -1
# El que murio espera a reaparecer para ver la animacion
scoreboard players set @s dd_wait 0
# Todos los demas la ven YA (con su sonido)
tag @s add dd_self
execute as @a[tag=!dd_self,scores={dd_wait=..-1}] run function darkness_death:start
tag @s remove dd_self
