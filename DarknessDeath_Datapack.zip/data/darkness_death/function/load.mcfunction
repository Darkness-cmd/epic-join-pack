scoreboard objectives add dd_deaths deathCount
scoreboard objectives add dd_wait dummy
scoreboard objectives add dd_t dummy
