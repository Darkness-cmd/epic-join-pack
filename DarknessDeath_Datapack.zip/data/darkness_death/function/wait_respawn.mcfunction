# Espera a que el jugador reaparezca (vivo) para lanzar la animacion
scoreboard players add @s dd_wait 1
execute if score @s dd_wait matches 3.. if entity @s[nbt={DeathTime:0s}] run function darkness_death:start
